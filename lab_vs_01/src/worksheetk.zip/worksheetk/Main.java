package worksheetk;

public class Main {
    public static void main(String[] args) {
        SurveyStationAccess s = new SurveyStationAccess("/Users/olepearse-danker/IdeaProjects/text_dateien_lab01/src/worksheet1/Messdaten.txt");


    }

}